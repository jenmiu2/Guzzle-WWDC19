//
//  arbol.swift
//  proyectoWWDC19
//
//  Created by Jennifer on 14/03/2019.
//  Copyright © 2019 Jennifer. All rights reserved.
//

public class Tree {
    var root: TreeNode
    var adaptation: Int
    public var steps: [(Int, Int)] = []
    
    public init(root: TreeNode) {
        self.root = root
        self.adaptation = 0
    }
}

