//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

public var mapToEvaluate = Map(col: 5, row: 5)

public class BoardView: UIView {
    let rows: Int
    let columns: Int
    var mapToShow: Map?
    var steps: [(Int, Int)]?
    
    public init(rows: Int, columns: Int, frame: CGRect = .zero) {
        self.rows = rows
        self.columns = columns
        super.init(frame: frame)
        didLoad()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func reloadData(map: Map, steps: [(Int, Int)]) {
        self.mapToShow = map
        self.steps = steps
        self.setNeedsDisplay()
    }
    
    func didLoad() {
        isOpaque = false
    }
    
    override public func draw(_ rect: CGRect) {
        let rowHeight: CGFloat = rect.height / CGFloat(rows)
        let columnWidth: CGFloat = rect.width / CGFloat(columns)
        
        
        UIColor(red: 0/255, green: 66/255, blue: 0/255, alpha: 1).setFill()
        for row in 0..<rows {
            for column in 0..<columns {
                let squareRect = CGRect(
                    x: columnWidth*CGFloat(column)+2,
                    y: rowHeight*CGFloat(row)+2,
                    width: columnWidth-4, height: rowHeight-4)
                let squarePath = UIBezierPath(rect: squareRect)
                squarePath.fill()
            }
        }
        
        UIColor(red: 0/255, green: 66/255, blue: 125/255, alpha: 1).setFill()
        for row in 0..<rows {
            for column in 0..<columns {
                if mapToShow?[row, column] == .food {
                    let circleRect = CGRect(
                        x: columnWidth*CGFloat(column)+2,
                        y: rowHeight*CGFloat(row)+2,
                        width: columnWidth-4, height: rowHeight-4)
                    let circlePath = UIBezierPath(ovalIn: circleRect)
                    circlePath.fill()
                }
            }
        }
        
        guard let steps = steps else {
            return
        }
        
        UIColor.red.setFill()
        for (x, y) in steps {
            let circleRect = CGRect(
                x: columnWidth*CGFloat(x)+2,
                y: rowHeight*CGFloat(y)+2,
                width: columnWidth-4, height: rowHeight-4)
            let circlePath = UIBezierPath(ovalIn: circleRect)
            circlePath.fill()
        }
    }
}

/* This function generate a random population for that insert a random tree on an array
 - Warning: numberOfElement and maxDepth more than 1
 
 - Usage:
 generatePopulation(numberOfElement: 2, maxDepth: 5)
 
 - Parameter:
 - numberOfElement: The size of the array
 - maxDepth: The depth of each tree
 
 - Returns: Array of Tree
 */

public func generatePopulation(numberOfElement: Int, maxDepth: Int) -> [Tree] {
    return (0..<numberOfElement).map { _ in Tree(root: TreeNode(maxDepth: maxDepth)) }
}

let board = BoardView(rows: mapToEvaluate.row, columns: mapToEvaluate.col)
board.frame = CGRect(x: 0, y: 0, width: 768, height: 768)

PlaygroundPage.current.liveView = board

/*This function is responsible for performing the genetic algorithm: generate population,
 evaluate each individuals of the population, select the best ones, cross each individuals
 of the population and mutate
 */
let numOfGeneration = 10
var population = generatePopulation(numberOfElement: 4,  maxDepth: 2)

var map = mapToEvaluate
for _ in 0..<numOfGeneration {
    //Evaluate each individual of the population
    for individual in population {
        map = evaluation(individual: individual, mapToEvaluate: mapToEvaluate)
    }
    
    //Select the best population
    population = selectionByTruncation(population: &population)
    if let best = population.first {
        map = evaluation(individual: best, mapToEvaluate: mapToEvaluate)
        board.reloadData(map: map, steps: best.steps)
    }
    
    //Cross individuals of the population
    cross(population: population)
    //Mutate some individuals of the population
    mutate(population: population)
}
